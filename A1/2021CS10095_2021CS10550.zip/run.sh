# Store the input filenames in variables
input_file1="$1"
input_file2="$2"

# Execute the 'main' executable with the provided input files
./main "$input_file1" "$input_file2"