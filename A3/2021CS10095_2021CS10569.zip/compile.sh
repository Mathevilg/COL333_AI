#part1
g++ part1.cpp -o part1_gensat
g++ writePart1.cpp -o part1_write


#part2
g++ part2.cpp -o part2